#ifndef LIST_H
#define LIST_H
/* List.h
 *
 * doubly-linked, double-ended list with Iterator interface
 * Project UID c1f28c309e55405daf00c565d57ff9ad
 * EECS 280 Project 4
 */

#include <iostream>
#include <cassert> //assert
#include <cstddef> //NULL


template <typename T>
class List {
  //OVERVIEW: a doubly-linked, double-ended list with Iterator interface
public:

  //EFFECTS:  returns true if the list is empty
    bool empty() const
    {  
        if (first == nullptr)
        {
            return true;
        }
        return false;
    }

  //EFFECTS: returns the number of elements in this List
    int size() const
    {
        int size = 0;
        Node* tmp_node_ptr = first;
        while (tmp_node_ptr != nullptr)
        {
            size++;
            tmp_node_ptr = tmp_node_ptr->next;
        }
        return size;
    }

  //REQUIRES: list is not empty
  //EFFECTS: Returns the first element in the list by reference
    T& front()
    {
         return first->datum;
  }

  //REQUIRES: list is not empty
  //EFFECTS: Returns the last element in the list by reference
    T& back()
    {
            return last->datum;
  }

  //EFFECTS:  inserts datum into the front of the list
    void push_front(const T& datum)
    {
        Node* tmp = new Node;
        tmp->prev = nullptr;
        tmp->next = first;
        tmp->datum = datum;

        if (first == nullptr)
        {
            first = tmp;
            last = tmp;
        }
        else
        {
            first->prev = tmp;
            first = tmp;
        }
        
  }

  //EFFECTS:  inserts datum into the back of the list
    void push_back(const T& datum)
    {
        Node* tmp = new Node;
        tmp->prev = last;
        tmp->next = nullptr;
        tmp->datum = datum;

        if (last == nullptr)
        {
            last = tmp;
            first = tmp;

        }
        else
        {
            last->next = tmp;
            last = tmp;
        }
        
  }

  //REQUIRES: list is not empty
  //MODIFIES: may invalidate list iterators
  //EFFECTS:  removes the item at the front of the list
    void pop_front()
    {
        if (!empty())
        {
            Node* tmp = first;
            first = tmp->next;
            if (first != nullptr)
            {
                first->prev = nullptr;
                delete tmp;
            }
            else
            {
                last = nullptr;
                //delete tmp;
                first = nullptr;
            }
        }
  }

  //REQUIRES: list is not empty
  //MODIFIES: may invalidate list iterators
  //EFFECTS:  removes the item at the back of the list
    void pop_back()
    {
        if (!empty())
        {
            Node* tmp = last;
            last = tmp->prev;
            if (last != nullptr)
            {
                last->next = nullptr;
            }
            else
            {
                first = nullptr;
            }
            delete tmp;
        }
  }

  //MODIFIES: may invalidate list iterators
  //EFFECTS:  removes all items from the list
    void clear()
    {
        Node* tmp = first;
        while (tmp != nullptr)
        {
            first = tmp->next;
            if (first != nullptr)
            {
                first->prev = nullptr;
            }
            delete tmp;
            tmp = first;
        }
  }

  // You should add in a default constructor, destructor, copy constructor,
  // and overloaded assignment operator, if appropriate. If these operations
  // will work correctly without defining these, you can omit them. A user
  // of the class must be able to create, copy, assign, and destroy Lists

    //default constructor
    List()
    {
        first = nullptr;
        last = nullptr;
    }
    //destructor
    ~List()
    {
    }
    //copy constructor
    List(const List<T>& other)
    {
        copy_all(other);
    }
private:
  //a private type
  struct Node {
    Node *next;
    Node *prev;
    T datum;
  };

  //REQUIRES: list is empty
  //EFFECTS:  copies all nodes from other to this
  void copy_all(const List<T>& other)
  {
      if (!empty())
      {
          clear();
      }
      Node* tmp = other.last;
      while (tmp != nullptr)
      {
          push_front(tmp->datum);
          tmp = tmp->prev;
      }
  }

  Node *first;   // points to first Node in list, or nullptr if list is empty
  Node *last;    // points to last Node in list, or nullptr if list is empty

public:
  ////////////////////////////////////////
  class Iterator {
    //OVERVIEW: Iterator interface to List

    // You should add in a default constructor, destructor, copy constructor,
    // and overloaded assignment operator, if appropriate. If these operations
    // will work correctly without defining these, you can omit them. A user
    // of the class must be able to create, copy, assign, and destroy Iterators.

    // Your iterator should implement the following public operators: *,
    // ++ (prefix), default constructor, == and !=.

  public:
    // This operator will be used to test your code. Do not modify it.
    // Requires that the current element is dereferenceable.
    Iterator& operator--() {
      assert(node_ptr);
      node_ptr = node_ptr->prev;
      return *this;
    }
    Iterator& operator++() {
        assert(node_ptr);
        node_ptr = node_ptr->next;
        return *this;
    }
    bool operator==(const Iterator& iter) const {
        bool res = node_ptr == iter.node_ptr;
        return res;
    }
    bool operator!=(const Iterator& iter) const {
        bool res = node_ptr != iter.node_ptr;
        return res;
    }
    T   operator*() const
    {
        assert(node_ptr);
        return node_ptr->datum;
    }
  private:
    Node *node_ptr; //current Iterator position is a List node
    // add any additional necessary member variables here

    // add any friend declarations here

  public:
      Node* getNode()
      {
          return node_ptr;
    }
    // construct an Iterator at a specific position
    Iterator(Node* p)
    {
        node_ptr = p;
    }

  };//List::Iterator
  ////////////////////////////////////////

  // return an Iterator pointing to the first element
  Iterator begin() const {
    return Iterator(first);
  }

  // return an Iterator pointing to "past the end"
  Iterator end() const
  {
      return Iterator(last);
  }

  //REQUIRES: i is a valid, dereferenceable iterator associated with this list
  //MODIFIES: may invalidate other list iterators
  //EFFECTS: Removes a single element from the list container
  void erase(Iterator i)
  {
      Node* i_node_ptr = i.getNode();
    if (validIterator(i) && i_node_ptr != nullptr)
    {
        if (i_node_ptr->prev != nullptr)
        {
            i_node_ptr->prev->next = i_node_ptr->next;
        }
        else {
            pop_front();
            return;
        }
        if (i_node_ptr->next != nullptr)
        {
            i_node_ptr->next->prev = i_node_ptr->prev;
        }
        else
        {
            pop_back();
            return;
        }
        delete i_node_ptr;
        i_node_ptr = i.getNode();
    }
  }

  //REQUIRES: i is a valid iterator associated with this list
  //EFFECTS: inserts datum before the element at the specified position.
  void insert(Iterator i, const T& datum)
  {
      Node* i_node_ptr = i.getNode();
      if (validIterator(i) && i_node_ptr != nullptr)
      {
          Node* tmp = new Node;
          tmp->prev = nullptr;
          tmp->next = nullptr;
          tmp->datum = datum;

          if (i_node_ptr->prev != nullptr)
          {
              i_node_ptr->prev->next = tmp;
              tmp->prev = i_node_ptr->prev;
          }
          else
          {
              first = tmp;
          }
          i_node_ptr->prev = tmp;
          tmp->next = i_node_ptr;
      }
  }

  bool validIterator(Iterator& itor)
  {
      Node* tmp = first;
      while (tmp != nullptr)
      {
          if (tmp == itor.getNode())
          {
              return true;
          }
          tmp = tmp->next;
      }
      return false;
  }

};//List


////////////////////////////////////////////////////////////////////////////////
// Add your member function implementations below or in the class above
// (your choice). Do not change the public interface of List, although you
// may add the Big Three if needed.  Do add the public member functions for
// Iterator.


#endif // Do not remove this. Write all your code above this line.

// Project UID c1f28c309e55405daf00c565d57ff9ad

#include "List.h"
#include "unit_test_framework.h"

using namespace std;

// Add your test cases here

TEST(test_list_empty) {
    List<int> empty_list;
    ASSERT_TRUE(empty_list.empty());
}
TEST(test1_list_empty_size) {
    List<int> empty_list;
    empty_list.empty();
    ASSERT_TRUE(empty_list.size() == 0);
}
TEST(test2_list_push_front_front) {
    List<int> test_list;
    test_list.push_front(100);
    ASSERT_TRUE(test_list.front() == 100);
}
TEST(test3_list_push_front_back) {
    List<int> test_list;
    test_list.push_front(101);
    ASSERT_TRUE(test_list.back() == 101);
}
TEST(test4_list_push_back_front) {
    List<int> test_list;
    test_list.push_back(102);
    ASSERT_TRUE(test_list.front() == 102);
}
TEST(test5_list_push_back_back) {
    List<int> test_list;
    test_list.push_front(103);
    ASSERT_TRUE(test_list.back() == 103);
}
TEST(test6_list_push_front_pop_front) {
    List<int> test_list;
    test_list.push_front(100);
    test_list.pop_front();
    ASSERT_TRUE(test_list.empty());
}
TEST(test7_list_push_front_pop_back) {
    List<int> test_list;
    test_list.push_front(100);
    test_list.pop_back();
    ASSERT_TRUE(test_list.empty());
}
TEST(test8_list_push_back_pop_front) {
    List<int> test_list;
    test_list.push_back(100);
    test_list.pop_front();
    ASSERT_TRUE(test_list.empty());
}
TEST(test9_list_push_back_pop_back) {
    List<int> test_list;
    test_list.push_back(100);
    test_list.pop_back();
    ASSERT_TRUE(test_list.empty());
}
TEST(test10_list_push_pop_all) {
    List<int> test_list;
    test_list.push_front(42);
    test_list.push_back(42);

    test_list.pop_front();
    test_list.pop_back();
    ASSERT_TRUE(test_list.empty());
}
TEST(test11_constructor_same) {
    List<int> test_list1;
    test_list1.push_front(100);
    test_list1.push_front(101);

    List<int> test_list2(test_list1);

    ASSERT_TRUE(test_list1.size() == test_list2.size());
}
TEST(test12_iterator_insert) {
    List<int> test_list;
    test_list.push_front(105);
    test_list.push_front(102);
    List<int>::Iterator iter = test_list.begin();
    test_list.insert(iter, 100);
    ASSERT_TRUE(test_list.front() == 100);
}
TEST(test13_iterator_insert_two) {
    List<int> test_list;
    test_list.push_front(100);
    List<int>::Iterator iter = test_list.begin();
    test_list.insert(iter, 100);
    iter = test_list.begin();
    test_list.insert(iter, 101);
    ASSERT_TRUE(test_list.size() == 3);
}
TEST(test14_iterator_erase_begin) {
    List<int> test_list;
    List<int>::Iterator iter = test_list.begin();
    test_list.insert(iter, 100);
    test_list.insert(iter, 101);
    iter = test_list.begin();
    test_list.erase(iter);
    iter = test_list.begin();
    test_list.erase(iter);
    ASSERT_TRUE(test_list.empty());
}
TEST(test15_iterator_erase_end) {
    List<int> test_list;
    List<int>::Iterator iter = test_list.end();
    test_list.insert(iter, 100);
    test_list.insert(iter, 101);
    iter = test_list.end();
    test_list.erase(iter);
    iter = test_list.end();
    test_list.erase(iter);
    ASSERT_TRUE(test_list.empty());
}
TEST(test16_iterator_operator_same) {
    List<int> test_list;
    test_list.push_front(100);
    List<int>::Iterator iter2 = test_list.end();
    List<int>::Iterator iter3 = iter2;
    ASSERT_TRUE(iter2 == iter3);
}
TEST(test17_iterator_operator_same_const) {
    List<int> test_list;
    test_list.push_front(100);
    List<int>::Iterator iter2 = test_list.end();
    const List<int>::Iterator iter3 = iter2;
    ASSERT_TRUE(iter2 == iter3);
}
TEST(test18_iterator_operator_same_const_const) {
    List<int> test_list;
    test_list.push_front(100);
    const List<int>::Iterator iter2 = test_list.end();
    const List<int>::Iterator iter3 = iter2;
    ASSERT_TRUE(iter2 == iter3);
}
TEST(test19_iterator_operator_nosame) {
    List<int> test_list;
    test_list.push_front(100);
    test_list.push_back(101);
    List<int>::Iterator iter1 = test_list.begin();
    List<int>::Iterator iter2 = test_list.end();
    ASSERT_TRUE(iter2 != iter1);
}
TEST(test20_iterator_operator_nosame_const) {
    List<int> test_list;
    test_list.push_front(100);
    test_list.push_back(101);
    List<int>::Iterator iter1 = test_list.begin();
    const List<int>::Iterator iter2 = test_list.end();
    ASSERT_TRUE(iter2 != iter1);
}
TEST(test21_iterator_operator_nosame_const_const) {
    List<int> test_list;
    test_list.push_front(100);
    test_list.push_back(101);
    const List<int>::Iterator iter1 = test_list.begin();
    const List<int>::Iterator iter2 = test_list.end();
    ASSERT_TRUE(iter2 != iter1);
}
TEST(test22_iterator_perator_get_iter_val) {
    List<int> test_list;
    test_list.push_front(100);
    test_list.push_back(101);
    const List<int>::Iterator iter1 = test_list.begin();
    ASSERT_TRUE(*iter1 == 100);
}
TEST(test23_iterator_operator_copy) {
    List<int> test_list;
    test_list.push_front(100);
    test_list.push_back(101);
    const List<int>::Iterator iter1 = test_list.begin();
    const List<int>::Iterator iter2 = iter1;
    ASSERT_TRUE(*iter2 == 100);
}
TEST(test24_iterator_operator_inc) {
    List<int> test_list;
    test_list.push_front(100);
    test_list.push_back(101);
    List<int>::Iterator iter1 = test_list.begin();
    ++iter1;
    ASSERT_TRUE(*iter1 == 101);
}
TEST(test25_iterator_operator_dec) {
    List<int> test_list;
    test_list.push_front(100);
    test_list.push_back(101);
    List<int>::Iterator iter1 = test_list.end();
    --iter1;
    ASSERT_TRUE(*iter1 == 100);
}
TEST(test26_iterator_operator_inc_dec) {
    List<int> test_list;
    test_list.push_front(100);
    test_list.push_back(101);
    List<int>::Iterator iter1 = test_list.end();
    ++--iter1;
    ASSERT_TRUE(*iter1 == 101);
}
TEST(test27_iterator_operator_dec_inc) {
    List<int> test_list;
    test_list.push_front(100);
    test_list.push_back(101);
    List<int>::Iterator iter1 = test_list.begin();
    --++iter1;
    ASSERT_TRUE(*iter1 == 100);
}
TEST(test28_iterator_operator_val_inc_dec) {
    List<int> test_list;
    test_list.push_front(100);
    test_list.push_back(101);
    List<int>::Iterator iter1 = test_list.end();
    ASSERT_TRUE(*++--iter1 == 101);
}
TEST(test29_iterator_operator_val_dec_inc) {
    List<int> test_list;
    test_list.push_front(100);
    test_list.push_back(101);
    List<int>::Iterator iter1 = test_list.begin();
    ASSERT_TRUE(*--++iter1 == 100);
}
TEST(test30_iterator_erase) {
    List<int> test_list;
    test_list.push_front(100);
    test_list.erase(test_list.begin());
    ASSERT_TRUE(test_list.size() == 0);
}
TEST(test31_push_front_iter_begin) {
    List<int> test_list;
    test_list.push_front(100);
    ASSERT_TRUE(*test_list.begin() == 100);
}
TEST(test32_push_back_iter_begin) {
    List<int> test_list;
    test_list.push_back(100);
    ASSERT_TRUE(*test_list.begin() == 100);
}
TEST(test33_push_front_iter_end) {
    List<int> test_list;
    test_list.push_front(100);
    ASSERT_TRUE(*test_list.end() == 100);
}
TEST(test34_push_back_iter_end) {
    List<int> test_list;
    test_list.push_back(100);
    ASSERT_TRUE(*test_list.end() == 100);
}
TEST(test35_push_front_set_front) {
    List<int> test_list;
    test_list.push_front(100);
    test_list.front() = 77;
    ASSERT_TRUE(test_list.front() == 77);
}
TEST(test36_push_front_set_back) {
    List<int> test_list;
    test_list.push_front(100);
    test_list.back() = 77;
    ASSERT_TRUE(test_list.front() == 77);
}
TEST(test37_push_back_set_front) {
    List<int> test_list;
    test_list.push_back(100);
    test_list.front() = 77;
    ASSERT_TRUE(test_list.front() == 77);
}
TEST(test38_push_back_set_back) {
    List<int> test_list;
    test_list.push_back(100);
    test_list.back() = 77;
    ASSERT_TRUE(test_list.front() == 77);
}
TEST(test39_iter_compare_begin_end) {
    List<int> test_list;
    test_list.push_front(100);
    ASSERT_TRUE(test_list.begin() == test_list.end());
}
TEST(test40_compare_begin_end) {
    List<int> test_list;
    test_list.push_front(100);
    ASSERT_TRUE(test_list.front() ==test_list.back());
}
TEST(test41_clear) {
    List<int> test_list;
    test_list.push_front(100);
    test_list.clear();
    ASSERT_TRUE(test_list.size() == 0);
}
TEST(test42_push_erase_insert1) {
    List<int> test_list;
    test_list.push_front(100);
    test_list.push_front(101);
    List<int>::Iterator iter1 = test_list.begin();
    test_list.erase(iter1);
    iter1 = test_list.begin();
    test_list.insert(iter1,102);
    ASSERT_TRUE(test_list.front() == 102);
}
TEST(test43_push_erase_insert2) {
    List<int> test_list;
    test_list.push_back(100);
    test_list.push_back(101);
    List<int>::Iterator iter1 = test_list.begin();
    test_list.erase(iter1);
    iter1 = test_list.begin();
    test_list.insert(iter1, 102);
    ASSERT_TRUE(test_list.front() == 102);
}
TEST(test44_push_erase_insert3) {
    List<int> test_list;
    test_list.push_front(100);
    test_list.push_front(101);
    List<int>::Iterator iter1 = test_list.end();
    test_list.erase(iter1);
    iter1 = test_list.end();
    test_list.insert(iter1, 102);
    ASSERT_TRUE(test_list.back() == 101);
}
TEST(test45_push_erase_insert4) {
    List<int> test_list;
    test_list.push_front(100);
    test_list.push_back(101);
    List<int>::Iterator iter1 = test_list.begin();
    test_list.erase(iter1);
    iter1 = test_list.begin();
    test_list.insert(iter1, 102);
    ASSERT_TRUE(test_list.front() == 102);
}
TEST(test46_push_front_insert) {
    List<int> test_list;
    test_list.push_front(100);
    List<int>::Iterator iter1 = test_list.begin();
    test_list.insert(iter1, 104);
    ASSERT_TRUE(test_list.front() == 104);
}
TEST(test47_insert_pop_back) {
    List<int> test_list;
    test_list.push_front(100);
    List<int>::Iterator iter1 = test_list.begin();
    test_list.insert(iter1, 104);
    test_list.pop_back();
    ASSERT_TRUE(test_list.front() == 104);
}
TEST(test48_push_insert_erase_front) {
    List<int> test_list;
    test_list.push_back(100);
    List<int>::Iterator iter1 = test_list.end();
    test_list.insert(iter1, 104);
    iter1 = test_list.end();
    test_list.erase(iter1);
    ASSERT_TRUE(test_list.front() == 104);
}
TEST(test49_push_insert_erase_back) {
    List<int> test_list;
    test_list.push_front(100);
    List<int>::Iterator iter1 = test_list.begin();
    test_list.insert(iter1, 104);
    iter1 = test_list.end();
    test_list.erase(iter1);
    ASSERT_TRUE(test_list.back() == 104);
}

TEST_MAIN()
